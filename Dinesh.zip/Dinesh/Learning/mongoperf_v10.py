import pymongo
import getpass
import dateutil.parser
from pymongo import MongoClient
import matplotlib.pyplot as plt, mpld3
import pandas as pd
from io import StringIO
from json2table import convert


myclient = pymongo.MongoClient("mongodb://localhost:27017/")
dss = myclient["dss"]
import subprocess
def makeTable(x):
	table = pd.read_table(StringIO(x),sep='\s+')
	htmlTable = table.to_html()
	return htmlTable

x = subprocess.check_output(r"C:\Users\tamilseu\Project\Project\POC\mongodb-win32-x86_64-2012plus-4.2.5\mongodb-win32-x86_64-2012plus-4.2.5\bin\mongostat.exe --humanReadable=false -o=insert=ObjInsertedPerSec,query=QryOpsPerSec,update=UpdOpsPerSec,delete=DelOpsPerSec,getmore=BatOpsPerSec,command=CmdsPerSec,dirty=PercOfDirtyBytes,used=PercOfUsedCache,flushes=ChkPtsTriggered,vsize=VirMmy(MB),res=ResMmy(MB),qrw=QLengthRW,arw=ActivRW,net_in=NWInBytesPerSec,net_out=NWOutBytesPerSec,conn=OpenConn,time=Time -n=5 5")
CTMD=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"CTMD"}]})
AAMS=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAMS"}]})
AAMC=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAMC"}]})
AAAS=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAAS"}]})
AALR=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AALR"}]})
AAMB=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAMB"}]})
ARAC=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"ARAC"}]})
AAOA=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAOA"}]})
AAGM=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAGM"}]})
AACC=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AACC"}]})
AUSA=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AUSA"}]})
AAMU=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAMU"}]})
AAMA=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAMA"}]})
AACA=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AACA"}]})
ACRU=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"ACRU"}]})
AAPP=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAPP"}]})
AAAP=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAAP"}]})
AULE=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AULE"}]})
ACPP=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"ACPP"}]})
AAAA=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAAA"}]})
ARUC=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"ARUC"}]})
AAAL=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"AAAL"}]})
ABPF=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"ABPF"}]})
ABUR=dss.ServiceRequests.count_documents({"$and":[{"createdTime":{"$gte":dateutil.parser.parse("2020-04-01T01:00:00.000Z"),"$lt":dateutil.parser.parse("2020-04-19T07:00:00.000Z")}},{'requestType':"ABUR"}]})
sr=(CTMD,AAMS,AAMC,AAAS,AALR,AAMB,ARAC,AAOA,AAGM,AACC,AUSA,AAMU,AAMA,AACA,ACRU,AAPP,AAAP,AULE,ACPP,AAAA,ARUC,AAAL,ABPF,ABUR)
srs=str(CTMD)+" "+str(AAMS)+" "+str(AAMC)+" "+str(AAAS)+" "+str(AALR)+" "+str(AAMB)+" "+str(ARAC)+" "+str(AAOA)+" "+str(AAGM)+" "+str(AACC)+" "+str(AUSA)+" "+str(AAMU)+" "+str(AAMA)+" "+str(AACA)+" "+str(ACRU)+" "+str(AAPP)+" "+str(AAAP)+" "+str(AULE)+" "+str(ACPP)+" "+str(AAAA)+" "+str(ARUC)+" "+str(AAAL)+" "+str(ABPF)+" "+str(ABUR)

DS=dss.command("dbstats")
#PS=dss.command("getProfilingStatus")
json_object = DS
build_direction = "TOP_TO_BOTTOM"
table_attributes = {"style" : "width:100%"}
html = convert(json_object, build_direction=build_direction, table_attributes=table_attributes)

print (srs)
print (x)
print (DS)
#print (PS)
print(html)
'<table style="width:100%"><tr><th>key</th><td>value</td></tr></table>'

fig = plt.figure()
# x-coordinates of left sides of bars  
left = [1, 2, 3, 4, 5]
# heights of bars 
height = [str(CTMD), str(AAMS), str(AAMC), str(AAAS), str(AALR)] 
# labels for bars 
tick_label = ['CTMD', 'AAMS', 'AAMC', 'AAAS', 'AALR'] 
# plotting a bar chart 
plt.bar(left, height, tick_label = tick_label, width = 0.8, color = ['red', 'green'])
# naming the x-axis 
plt.xlabel('Service Requests') 
# naming the y-axis 
plt.ylabel('No. of Service Requests') 
# plot title 
plt.title('Service Requests Trend') 

#return {"js": script, "html": div}
#plugins.connect(fig, extra.InteractiveLegendPlugin())
  
html_graph = mpld3.fig_to_html(fig)
fig.savefig('bargraph.png')
#print (html_graph) 

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase

From = "tamilseu@anz.com"
#pwd = getpass.getpass() 
try: 
    pwd = getpass.getpass() 
except Exception as error: 
    print('ERROR', error) 
#else: 
#    print('Password entered:', pwd)
print ("++From User Added")
To = ["udhayakumar.tamilselvan@anz.com"]
print ("++SendTo User Added")

with smtplib.SMTP("mailau.corp.anz.com", 25) as server:
   print ("++Connection Established")
   server.ehlo()
   server.starttls()
   server.ehlo()
   print("++Starting Tls")
   bar = 'bargraph.png'
   msg = MIMEMultipart()
   msg['From'] = 'tamilseu@anz.com'
   msg['Subject'] = 'MongoDB Performance Statistics during PnV run'
   body = '''<!Doctype html>
   <body>'''
   body += 'Team,'
   body += '''<br/><br/>''''Please find below, the MongoDB performance statistics for the last PnV run...'
   body += '''<br/><br/>'''
   body += makeTable(x.decode("utf-8"))
   body += '''<br/><br/>'''
   body += 'Below are the no. of DSS Service Requests created during the PnV run for each category...'
   body += '''<table border=1>
   <tr bgcolor=orange><td>Claim Missing Deposit</td><td>Amend Signatory</td><td>Amend Digital Channel Details</td><td>Add Signatory</td><td>AmendLegalEntityAdminLiquidatorReceiver</td><td>Amend Billing Details</td><td>Delete Account</td><td>OpenAccount</td><td>Amend Group Mandate</td><td>Close Digital Channel</td><td>Amend Statement Address</td><td>Amend User on Digital Channel</td><td>Amend Account on Digital Channel</td><td>Close Account</td><td>Delete Signatory</td><td>Add Periodical Payment</td><td>Amend Periodical Payment</td><td>Amend Legal Entity Name</td><td>Close Periodical Payment</td><td>Add Account</td><td>Delete User</td><td>Add Loan Deal</td><td>Manage BPAY Facility</td><td>Manage Bureau (Payments)</td></tr>
   <tr><td>''' +str(CTMD)+ '''</td><td>''' +str(AAMS)+'''</td><td>''' +str(AAMC)+'''</td><td>''' +str(AAAS)+'''</td><td>''' +str(AALR)+'''</td><td>''' +str(AAMB)+'''</td><td>''' +str(ARAC)+'''</td><td>''' +str(AAOA)+'''</td><td>''' +str(AAGM)+'''</td><td>''' +str(AACC)+'''</td><td>''' +str(AUSA)+'''</td><td>''' +str(AAMU)+'''</td><td>''' +str(AAMA)+'''</td><td>''' +str(AACA)+'''</td><td>''' +str(ACRU)+'''</td><td>''' +str(AAPP)+'''</td><td>''' +str(AAAP)+'''</td><td>''' +str(AULE)+'''</td><td>''' +str(ACPP)+'''</td><td>''' +str(AAAA)+'''</td><td>''' +str(ARUC)+'''</td><td>''' +str(AAAL)+'''</td><td>''' +str(ABPF)+'''</td><td>''' +str(ABUR)+'''</td></tr>
   </table>'''
   body += '''<br/><br/>'''
   body += '''<img src="cid:'''+bar+'''">'''
   body += '''<br/><br/>'''
   body += '''<b>''''DB Statistics:''''</b>''''''<br/>'''
   body += '''<br/>'''
   body += html
   body += '''<br/><br/>'''
   body += '\n\nRegards,'
   body += '''<br/>''''PnV Team'
   body += '''<br/><br/>'''
   body += '***************************************************************This is an auto-generated email***************************************************************'
   body += '''</body>
   </html>'''
   
   image = open('bargraph.png', 'rb')
   img = MIMEImage(image.read(), 'png')
   image.close()
   img.add_header('Content-Id', '<{}>'.format(bar))
   msg.attach(img)
   msg.attach(MIMEText(body,'html'))
   try:
    server.login(From, pwd)
    print("++Login Successful")
    for i in To:
        msg['To'] = i
        text=msg.as_string()
        server.sendmail(From, i, text)
        print("done")
   except Exception as ex:
    print(ex)


