delete from SIEBEL.S_SRM_DATA
where PAR_ID in
(
   select ROW_ID from SIEBEL.S_SRM_REQUEST
   where STATUS in ('COMPLETE', 'SUCCESS', 'EXPIRED', 'CANCELED')
        and ACTL_END_DT <= '20/May/21'
);
commit;

delete from SIEBEL.S_SRM_REQ_PARAM
where REQ_ID in 
(
   select ROW_ID from SIEBEL.S_SRM_REQUEST
   where STATUS in ('COMPLETE', 'SUCCESS', 'EXPIRED', 'CANCELED')
        and ACTL_END_DT <= '20/May/21'
);
commit;

delete from SIEBEL.S_SRM_REQUEST
where STATUS in ('COMPLETE', 'SUCCESS', 'EXPIRED', 'CANCELED')
   and ACTL_END_DT <= '20/May/21'
commit;
Delete from siebel.s_communication where SRC_ID in('2-JXK753B','2-JXK753N','2-JXK752Z','2-JXK754Z','2-JXT0UFZ','2-JXT0UGB');
commit;
delete from siebel.S_SRV_REQ_XM where type = 'FATCA' and created >= '1-MAY-18';
delete from siebel.S_ORG_EXT_XM where type = 'FATCA' and created >= '1-MAY-18';
delete from siebel.S_CONTACT_XM where type = 'FATCA' and created >= '1-MAY-18';

commit;

Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'Suresh01%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'nighte%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'Aquire%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'new%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'Yellow%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'Btriangle%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'crs%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'APP%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'create%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'hope%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'hope%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'segret%') and CON_TYPE_CD is null;
Delete from siebel.S_COMMUNICATION Where PR_CON_ID IN (Select ROW_ID from Siebel.s_contact Where FST_NAME like 'soori%') and CON_TYPE_CD is null;
Commit;

Update SIEBEL.S_CAMP_CON Set STAT_CD = 'New' Where ROW_ID IN
(SELECT
     T12.ROW_ID
   FROM 
       SIEBEL.S_BU T1,
       SIEBEL.S_POSTN T2,
       SIEBEL.S_SRC T3,
       SIEBEL.S_CONTACT T4,
       SIEBEL.S_SRC T5,
       SIEBEL.S_SRC T6,
       SIEBEL.S_LOY_MEMBER T7,
       SIEBEL.S_USER T8,
       SIEBEL.S_PRSP_CONTACT T9,
       SIEBEL.S_ORG_EXT T10,
       SIEBEL.S_CAMP_LD_WAVE T11,
       SIEBEL.S_CAMP_CON T12
   WHERE 
      T12.SRC_ID = T3.ROW_ID AND
      T12.LAST_UPD_BY = T8.PAR_ROW_ID (+) AND
      T12.CAMP_LD_WAVE_ID = T11.ROW_ID (+) AND
      T3.MKTG_PLAN_ID = T6.ROW_ID (+) AND
      T12.CON_PER_ID = T7.PR_CON_ID (+) AND
      T12.BU_ID = T1.ROW_ID (+) AND
      T12.POSTN_ID = T2.ROW_ID (+) AND
      T3.ULT_PAR_SRC_ID = T5.ROW_ID (+) AND
      T12.CON_PER_ID = T4.PAR_ROW_ID (+) AND
      T12.CON_PR_DEPT_OU_ID = T10.PAR_ROW_ID (+) AND
      T12.PRSP_CON_PER_ID = T9.ROW_ID (+) AND
      T12.CON_PER_ID is not null AND
      ((T3.PROG_START_DT <= TO_DATE('04/12/2019 14:29:59','MM/DD/YYYY HH24:MI:SS') AND T3.PROG_END_DT >= TO_DATE('04/11/2019 14:30:00','MM/DD/YYYY HH24:MI:SS') AND NVL (T12.X_LEAD_EXPIRY_DT, T3.PROG_END_DT) >= TO_DATE('04/11/2019 14:30:00','MM/DD/YYYY HH24:MI:SS') AND T3.STATUS_CD = 'Launched' AND T3.CUST_TRGT_TYPE_CD LIKE '%Outbound%' AND T12.X_BUSINESS_UNIT = 'iKnow Commercial') AND
      (T12.X_BUSINESS_UNIT ='iKnow Commercial')));
      commit;
/


exit